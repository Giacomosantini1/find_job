# Come integrare la Fase 3 (Silver Layer) nel repository esistente

Stessa procedura già usata per la Fase 2, via GitHub Codespaces.

## Contenuto di questo pacchetto

```
src/silver/
    __init__.py
    schema.py              (nuovo) - schema canonico Silver
    transformer.py         (nuovo) - legge Bronze, normalizza, upsert su Silver
    mappers/
        __init__.py
        base.py              (nuovo) - contratto SourceMapper + SilverRecord
        greenhouse.py        (nuovo)
        smartrecruiters.py   (nuovo)
        registry.py          (nuovo) - aggiungere una fonte = una riga qui
tests/
    test_silver_mappers.py       (nuovo) - test puri, no Spark, istantanei
    test_silver_transformer.py   (nuovo) - test reali con Spark+Delta
```

Verificato in locale prima della consegna:
- `ruff check` → All checks passed
- `mypy` → Success, no issues found
- 7 test totali passati (4 mapper + 3 transformer, incluso MERGE reale su Delta)

## Procedura

1. Apri (o riapri) il Codespace del repository:
   **`<> Code` → Codespaces → Create/riapri codespace on main**.
2. **Prima di tutto**, allinea il Codespace con eventuali commit fatti da
   browser nel frattempo (stessa cautela della volta scorsa):
   ```bash
   git pull origin main --rebase
   ```
3. Trascina questo zip (`fase3-silver.zip`) nell'Explorer di VS Code web.
4. Nel terminale:
   ```bash
   unzip fase3-silver.zip -d /tmp/fase3
   cp -r /tmp/fase3/fase3-package/src/silver src/
   cp /tmp/fase3/fase3-package/tests/test_silver_mappers.py tests/
   cp /tmp/fase3/fase3-package/tests/test_silver_transformer.py tests/
   rm fase3-silver.zip
   rm -rf /tmp/fase3
   ```
5. Verifica che tutto sia al posto giusto:
   ```bash
   find src/silver tests -type f
   ```
6. Commit e push:
   ```bash
   git add -A
   git commit -m "Fase 3: Silver layer (schema canonico + mapper Greenhouse/SmartRecruiters + upsert Delta)"
   git push
   ```
7. Vai sulla tab **Actions**: questa volta il job durerà **3-4 minuti**
   (i test del transformer includono due cicli completi di scrittura +
   MERGE su Delta, più pesanti di quelli della Fase 2). È normale.

## Cosa fa concettualmente questa fase

- `mappers/` traduce ogni payload grezzo (diverso per fonte) nello stesso
  schema canonico (`job_id, company, title, location, remote, salary,
  description, technologies, source, publication_date, link`).
- `technologies` resta `None` qui: viene popolato dalla Fase 5 (Skill
  Extraction), che lavora sulla `description` già pulita da HTML.
- `transformer.py` fa un **upsert** (MERGE INTO) su `job_id`: Silver
  rappresenta sempre lo stato corrente delle offerte, a differenza di
  Bronze che è uno storico append-only completo.
- Aggiungere una fonte futura (es. Workday) richiede solo: un nuovo file
  in `mappers/`, una riga in `registry.py`. Nessuna modifica a
  `transformer.py` o `schema.py`.
