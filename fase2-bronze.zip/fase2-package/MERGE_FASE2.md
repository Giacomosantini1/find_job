# Come integrare la Fase 2 (Bronze Layer) nel repository esistente

Questo pacchetto contiene **solo i file nuovi/modificati** della Fase 2,
da unire al repository `find_job` già presente su GitHub (quello con
`src/ingestion/`, `tests/test_connectors.py`, ecc. già a posto).

## Contenuto di questo pacchetto

```
src/bronze/
    __init__.py
    schema.py          (nuovo)
    spark_session.py   (nuovo)
    writer.py           (nuovo)
tests/
    test_bronze_writer.py  (nuovo)
requirements.txt      (aggiornato: aggiunge pyspark + delta-spark)
```

## Procedura (via GitHub Codespaces, stesso ambiente già usato prima)

1. Apri il tuo repository su github.com, clicca **`<> Code` → Codespaces →
   Create codespace on main** (o riapri il Codespace già creato prima, se
   ancora attivo).
2. Nel terminale del Codespace, carica questo zip trascinandolo nell'area
   file di VS Code web, poi:

   ```bash
   unzip fase2-bronze.zip -d /tmp/fase2
   cp -r /tmp/fase2/src/bronze src/
   cp /tmp/fase2/tests/test_bronze_writer.py tests/
   cp /tmp/fase2/requirements.txt .
   ```

3. Verifica che tutto sia al posto giusto:

   ```bash
   find src/bronze tests -type f
   ```

4. Commit e push:

   ```bash
   git add -A
   git commit -m "Fase 2: Bronze layer (Delta Lake, append-only)"
   git push
   ```

5. Vai sulla tab **Actions**: il CI ripartirà. Nota bene — i test di
   questa fase usano PySpark + Delta Lake per davvero (non mock), quindi
   il job CI impiegherà 1-2 minuti in più rispetto a prima (scaricamento
   dei jar Delta al primo avvio). È normale, non è un errore.

## Nota su Java

PySpark richiede una JVM. I runner GitHub-hosted (`ubuntu-latest`) hanno
Java preinstallato di default, quindi il CI dovrebbe funzionare senza
modifiche. Se in futuro lavori in locale sul tuo PC e PySpark non parte,
verifica di avere Java 11+ installato (`java -version`).
